../bin/edge --log-level trace --work-dir ./ --edge-config-file ./mimikEdgePub.lic --api-port 8082

