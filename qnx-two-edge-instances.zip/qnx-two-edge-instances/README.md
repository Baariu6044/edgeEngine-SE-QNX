# edgeengine
edgeEngine for QNX

# Installation Guide
1. Put qnx-disk folder on QNX Hypervisor

3. Run start script to start edgeEngine.
```
cd mimik/instance1
./start.sh
```

```
cd mimik/instance2
./start.sh
```
4. Please visit https://developer.mimik.com and create your account and a project to get the client ID and developer ID token
5. On the development PC, install visual studio code (vscode)
6. On the development PC, open visual studio code, and install plugin REST Client
7. On the development PC, use visual studio code to open local/instance1.http to setup mdebug microservice on instance1, and make API call
8. Fill in the IP, clientId, and developerIdToken.
9. On the development PC, use visual studio code to open local/instance2.http to setup mdebug microservice on instance2, and make API call
10. Fill in the IP, clientId, and developerIdToken
